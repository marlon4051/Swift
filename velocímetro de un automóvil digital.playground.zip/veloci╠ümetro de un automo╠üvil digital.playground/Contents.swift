//velocímetro de un automóvil digital

import UIKit

enum Velocidades :Int{
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    init( velocidadInicial : Velocidades ){
        self = velocidadInicial
    }
}

class Auto {
    var velocidad: Velocidades
    
    init(){
        velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
    }
    
    func cambioDeVelocidad()-> ( actual : Int, velocidadEnCadena: String){
        
        if velocidad == Velocidades.Apagado{
            
            velocidad = Velocidades.VelocidadBaja

        }else if velocidad == Velocidades.VelocidadBaja {
            
            velocidad = Velocidades.VelocidadMedia
            
        }else if velocidad == Velocidades.VelocidadMedia {
            
            velocidad = Velocidades.VelocidadAlta
            
        }else if velocidad == Velocidades.VelocidadAlta {
            
            velocidad = Velocidades.VelocidadMedia
            
        }
        return (velocidad.rawValue,"\(velocidad)")
    }
    
}

var auto = Auto()

print("Velocidad inicial del auto  \(auto.velocidad.rawValue), \(auto.velocidad) ")

for i in 0 ..< 20 {
    print(auto.cambioDeVelocidad())
}