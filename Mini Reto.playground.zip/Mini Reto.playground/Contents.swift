

import UIKit


/*
 El siguiente bloque de codigo muestra el mini reto, pero suponiendo que los numeros pueden cumplir varias de las condiciones a la vez, es decir, el 5 es par, pero tambien divisible entre 5,
 muestra el mensaje 5 impar y 5 Bingo. Esto se cumple con todos los demas como en el rango de 30 a 40, el 35 cumple que es impar, que es divisible y que se  encuentra en el rango por lo
 tanto muestra 3 mensajes, 35 Bingo, 35 Impar, 35 Viva Swift
*/

for i in 0...100{
    if i % 5 == 0{
        print("\(i)\tBingo")
    }
    if i % 2 == 0{
        print("\(i)\tPar")
    }
    if i % 2 != 0{
        print("\(i)\tImpar")
    }
    if i >= 30 && i <= 40 {
        print("\(i)\tViva Swift")
    }
        
}
